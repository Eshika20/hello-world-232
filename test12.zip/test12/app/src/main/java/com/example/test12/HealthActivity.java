package com.example.test12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class HealthActivity extends AppCompatActivity {
    private CheckBox check1;
    private CheckBox check2;
    private CheckBox check3;
    private CheckBox check4;
    private CheckBox check5;
    private CheckBox check6;
    private CheckBox check7;
    private CheckBox check8;
    private CheckBox check9;
    private CheckBox check10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.health);
        addListenerToCheckBox();
        addlistenertosymptoms();
    }

    public void addlistenertosymptoms() {

        check2 = (CheckBox) findViewById(R.id.checkBox2);
        check3 = (CheckBox) findViewById(R.id.checkBox3);
        check4 = (CheckBox) findViewById(R.id.checkBox4);
        check5 = (CheckBox) findViewById(R.id.checkBox5);
        check6 = (CheckBox) findViewById(R.id.checkBox6);
        check7 = (CheckBox) findViewById(R.id.checkBox7);
        check8 = (CheckBox) findViewById(R.id.checkBox8);
        check9 = (CheckBox) findViewById(R.id.checkBox9);
        boolean checked1, checked2, checked3, checked4, checked5;
        boolean checked6, checked7, checked8, checked9;

        check2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean checked2 = ((CheckBox) view).isChecked();
                if(checked2){
                    check4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            boolean checked4 = ((CheckBox) view).isChecked();
                            if(checked4){
                                check8.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        boolean checked8 = ((CheckBox) view).isChecked();
                                        if(checked8){
                                            Toast.makeText(HealthActivity.this,
                                                    "You might have Covid -- Visit Doctor",Toast.LENGTH_LONG).show();

                                        }
                                        else {
                                            check3.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View view) {
                                                    boolean checked3 = ((CheckBox) view).isChecked();
                                                    if(checked3){
                                                        check6.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View view) {
                                                                boolean checked6 = ((CheckBox) view).isChecked();
                                                                if(checked6){
                                                                    Toast.makeText(HealthActivity.this,
                                                                            "You might have Covid -- Visit Doctor",Toast.LENGTH_LONG).show();

                                                                }
                                                                else{
                                                                    check5.setOnClickListener(new View.OnClickListener() {
                                                                        @Override
                                                                        public void onClick(View view) {
                                                                            boolean checked2 = ((CheckBox) view).isChecked();
                                                                            if(checked2){
                                                                                Toast.makeText(HealthActivity.this,
                                                                                        "Please take rest at home",Toast.LENGTH_LONG).show();

                                                                            }
                                                                            else {
                                                                                check7.setOnClickListener(new View.OnClickListener() {
                                                                                    @Override
                                                                                    public void onClick(View view) {
                                                                                        boolean checked7 = ((CheckBox) view).isChecked();
                                                                                        if (checked7) {
                                                                                            Toast.makeText(HealthActivity.this,
                                                                                                    "Please take rest at home", Toast.LENGTH_LONG).show();

                                                                                        } else {
                                                                                            Toast.makeText(HealthActivity.this,
                                                                                                    "Please take rest at home", Toast.LENGTH_LONG).show();

                                                                                        }
                                                                                    }
                                                                                });
                                                                            }
                                                                            }
                                                                        });
                                                                    }
                                                                }
                                                            });
                                                        }
                                                    }

                                            });
                                        }
                                    }
                                });
                            }
                            else{
                                check8.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        boolean checked5 = ((CheckBox) view).isChecked();
                                        if(checked5){
                                            Toast.makeText(HealthActivity.this,
                                                    "You might have Covid -- Visit Doctor",Toast.LENGTH_LONG).show();

                                        }
                                        else{
                                            Toast.makeText(HealthActivity.this,
                                                    "Please take rest at home",Toast.LENGTH_LONG).show();

                                        }
                                    }
                                });
                        }
                        }
                    });
                }
                else{
                    check7.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            boolean checked7 = ((CheckBox) view).isChecked();
                            if(checked7){
                                check5.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        boolean checked5 = ((CheckBox) view).isChecked();
                                        if(checked5){
                                            check6.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View view) {
                                                    Toast.makeText(HealthActivity.this,
                                                            "You might have Covid -- Visit Doctor",Toast.LENGTH_LONG).show();

                                                }
                                            });
                                        }
                                        else{
                                            check4.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View view) {
                                                    Toast.makeText(HealthActivity.this,
                                                            "You might have Covid -- Visit Doctor",Toast.LENGTH_LONG).show();

                                                }
                                            });
                                        }
                                    }
                                });
                            }
                            else{
                                check8.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        boolean checked8 = ((CheckBox) view).isChecked();
                                        if(checked8){
                                            Toast.makeText(HealthActivity.this,
                                                    "You might have Covid -- Visit Doctor",Toast.LENGTH_LONG).show();

                                        }
                                        else{
                                            Toast.makeText(HealthActivity.this,
                                                    "Please take rest at home",Toast.LENGTH_LONG).show();

                                        }
                                    }
                                });
                            }
                        }
                    });
            }
            }
        });





    }

        public void addListenerToCheckBox(){
            check1 = (CheckBox) findViewById(R.id.checkBox);
            check1.setOnClickListener
                    (new View.OnClickListener() {
                         @Override
                         public void onClick(View view) {
                             boolean checked = ((CheckBox) view).isChecked();
                             if (checked) {
                                 Toast.makeText(HealthActivity.this,
                                         "You are safe from Covid", Toast.LENGTH_LONG).show();
                             } else {
                                 Toast.makeText(HealthActivity.this,
                                         "Visit nearby Vaccination center", Toast.LENGTH_LONG).show();
                             }

                         }
                     }

                    );

        }
    }

