package com.example.test12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;

public class WebsegActivity extends AppCompatActivity {
    private static Button bu1;
    private static EditText ulr1;
    private static WebView browser1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webseg);
        openurl1();

    }

    public void openurl1() {
        bu1 = (Button) findViewById(R.id.button6);
        ulr1 = (EditText) findViewById(R.id.edittext6);
        browser1 = (WebView) findViewById(R.id.webview6);
        bu1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String http = ulr1.getText().toString();
                browser1.getSettings().setLoadsImagesAutomatically(true);
                browser1.getSettings().setJavaScriptEnabled(true);
                browser1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                browser1.loadUrl(http);

            }
        });


    }
}